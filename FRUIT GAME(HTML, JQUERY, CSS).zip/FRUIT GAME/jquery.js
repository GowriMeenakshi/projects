var playing = false;
var score;
var trialsleft ;
$(function(){
    // click on start reset button
    $("#startreset").click(function(){
      //are we playing
        //yes
            //reload page  
        if(playing == true){
            location.reload();
        }else{ 
        //no
            // show trial left
            playing = true; // game initiated
            score = 0;
            //set score to 0
            $("#scorevalue").html(score);
            
            //show trials left
            $("#trialsleft").show();
            trialsleft = 3;
            
            addhearts();  
         //change button to reset game
            $("#startreset").html("Reset game");
            //1.create a random fruit
            startAction();
        }
         
    });
});

    
            
            // define random step
            //2.move fruit one step every 30 seconds
                // is too low
                    //no-> repeat 2
                    //yes-> trial left?
                        // repeat 1,delete trial heart
                    //no
                    // Game over, show start game

//slice fruit
    //play sound
    //explode fruit
function addhearts(){
for(i=0;i < trialsleft; i++){
               $("#trialsleft").append('<img src="images/heart.png" class="life">');
            }
   }

function startAction(){
    //start sending fruits
    $("#fruitcontainer").append('<img src="images/apple.png" class="life">');
    
}